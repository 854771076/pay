from django.shortcuts import render,HttpResponse,redirect
from .models import *
# Create your views here.
from django import forms
import datetime
from django.db.models import Sum,Count
from django.core.paginator import Paginator, PageNotAnInteger, InvalidPage, EmptyPage

class UserForm(forms.Form):
      
      username = forms.CharField(label='用户名',max_length=50)
      password = forms.CharField(label='密码',widget=forms.PasswordInput())
 
 
def login(request):
     status=request.GET.get('status')
     userform = UserForm(request.POST)
     show=request.GET.get('show')
     
     if show==None:
         show='营收情况'
     if request.method == 'POST':
         userform = UserForm(request.POST)
         keep=request.POST.get('keep')
         if userform.is_valid():
             username = userform.cleaned_data['username']
             password = userform.cleaned_data['password']
             if keep!=None:
                request.session['username']=username
                request.session['password']=password
             else:
                request.session['username']=None
                request.session['password']=None
             user = Users.objects.filter(username__exact=username,psw__exact=password).values_list()
             
             if user:
                 u=Users.objects.get(username=username)
                 return render(request,'index.html',{'userform':userform,'name':u.sname,'points':Points.objects.get(sname=u.sname).points,'username':username,'password':password,'show':show,'userstatus':u.status})
             else:
                 return render(request,'login.html',{'userform':userform,'status':'false'})
     username=request.session.get('username')
     if request.session and status!='logout' and username!='' and username!=None:
        
        password=request.session.get('password')
        if username==None:
            pass
        else:
            user = Users.objects.filter(username__exact=username,psw__exact=password).values_list()
            if user:
                u=Users.objects.get(username=username)
                return render(request,'index.html',{'userform':userform,'name':user[0][2],'points':Points.objects.get(sname=user[0][2]).points,'username':username,'password':password,'show':show,'userstatus':u.status})
            else:
                return render(request,'login.html',{'userform':userform,'status':'shixiao'})
     else:
         userform = UserForm()
     return render(request,'login.html',{'userform':userform})
def changepsw(request,name):
    sname=name
    if request.GET and request.method=='GET':
        username=request.GET.get('username')
        password=request.GET.get('psw')
        if password!=Users.objects.get(username=username).psw:#安全验证
            return HttpResponse(f'账号验证失败！')
        return render(request,'changepsw.html',{'username':username,'password':password,'name':sname})
    else:
        username=request.POST.get('username')
        password=request.POST.get('psw')
        repassword=request.POST.get('repsw')
        if password!=repassword:
            
            return render(request,'changepsw.html',{'status':'两次密码不一致','name':sname,'password':password,'username':username})
        try:
            
            user=Users.objects.get(sname=sname)
            user.username=username
            if password==user.psw:
                return render(request,'changepsw.html',{'status':'不能与原密码一致','name':sname,'password':password,'username':username})
            user.psw=password
            user.save()
            return render(request,'changepsw.html',{'username':username,'password':password,'status':'True','name':sname})
        except Exception as e:
            return render(request,'changepsw.html',{'status':e,'name':sname,'password':password,'username':username})
def filter_time(show,data,year,month,day,way):
    if way !='全部':
        way=way+'支付'
    if show=='营收情况' or show=='数据分析':
            if way!='全部':#付款方式筛选
                data=data.filter(付款方式=way)
            if year=='all' and month=='all'  and day=='all':#全部
                data=data
            elif  year=='all' and month=='all'  and day!='all':#所有日期为day的数据
                data=data.filter(付款时间__day=int(day))
            elif year=='all' and month!='all'  and day=='all':#所有月份为month的数据
                data=data.filter(付款时间__month=int(month))
            elif year=='all' and month!='all'  and day!='all':#所有日期为month-day的数据
                data=data.filter(付款时间__month=int(month)).filter(付款时间__day=int(day)) 
            elif year!='all' and month=='all'  and day=='all':#所有年份为year的数据    
                data=data.filter(付款时间__year=int(year))
            elif  year!='all' and month=='all'  and day!='all':#所有年份为year鈤为day的数据    
                data=data.filter(付款时间__year=int(year)).filter(付款时间__day=int(day))
            elif year!='all' and month!='all'  and day=='all':#所有年份为year月份为month的数据  
                data=data.filter(付款时间__year=int(year)).filter(付款时间__month=int(month)) 
            elif year!='all' and month!='all'  and day!='all':#所有日期为year-month-day的数据   
                data=data.filter(付款时间__year=int(year)).filter(付款时间__month=int(month)).filter(付款时间__day=int(day)) 
            return data.order_by('-付款时间')
    elif show=='积分记录':
            if year=='all' and month=='all'  and day=='all':#全部
                data=data
            elif  year=='all' and month=='all'  and day!='all':#所有日期为day的数据
                data=data.filter(time__day=int(day))
            elif year=='all' and month!='all'  and day=='all':#所有月份为month的数据
                data=data.filter(time__month=int(month))
            elif year=='all' and month!='all'  and day!='all':#所有日期为month-day的数据
                data=data.filter(time__month=int(month)).filter(time__day=int(day)) 
            elif year!='all' and month=='all'  and day=='all':#所有年份为year的数据    
                data=data.filter(time__year=int(year))
            elif  year!='all' and month=='all'  and day!='all':#所有年份为year鈤为day的数据    
                data=data.filter(time__year=int(year)).filter(time__day=int(day))
            elif year!='all' and month!='all'  and day=='all':#所有年份为year月份为month的数据  
                data=data.filter(time__year=int(year)).filter(time__month=int(month)) 
            elif year!='all' and month!='all'  and day!='all':#所有日期为year-month-day的数据   
                data=data.filter(time__year=int(year)).filter(time__month=int(month)).filter(time__day=int(day)) 
            return data.order_by('-time') 
    elif  show=='购买记录':
            if year=='all' and month=='all'  and day=='all':#全部
                data=data
            elif  year=='all' and month=='all'  and day!='all':#所有日期为day的数据
                data=data.filter(time__day=int(day))
            elif year=='all' and month!='all'  and day=='all':#所有月份为month的数据
                data=data.filter(time__month=int(month))
            elif year=='all' and month!='all'  and day!='all':#所有日期为month-day的数据
                data=data.filter(time__month=int(month)).filter(time__day=int(day)) 
            elif year!='all' and month=='all'  and day=='all':#所有年份为year的数据    
                data=data.filter(time__year=int(year))
            elif  year!='all' and month=='all'  and day!='all':#所有年份为year鈤为day的数据    
                data=data.filter(time__year=int(year)).filter(time__day=int(day))
            elif year!='all' and month!='all'  and day=='all':#所有年份为year月份为month的数据  
                data=data.filter(time__year=int(year)).filter(time__month=int(month)) 
            elif year!='all' and month!='all'  and day!='all':#所有日期为year-month-day的数据   
                data=data.filter(time__year=int(year)).filter(time__month=int(month)).filter(time__day=int(day)) 
            return data.order_by('-time') 
def data_day(history,days,month):
      dic={}
      for i in range(1,days[month]+1):   
         dic[f'{i}']=history.filter(付款时间__day=i)
      return dic.items()
def data_month(history):
      dic={}
      for i in range(1,13):   
         dic[f'{i}']=history.filter(付款时间__month=i)
      return dic.items()
def dataview_root(request):
        root=request.GET.get('root')
        if root!='dajlfjlasjflasjf46546':
            return HttpResponse('404')
        years=datetime.datetime.now()
        nowmonth=str(years.month)
        years=[i for i in range(2021,years.year+1)] 
        sname=request.GET.get('sname')
        data=History.objects.filter(sname=sname)
        #时间筛选
        day='all'
        if request.POST:
            year=request.POST.get('year')
            month=request.POST.get('month')
            
            way=request.POST.get('way')
            data=filter_time('数据分析',data,year,month,day,way)
            
            if year=='all':
                two=29
            elif int(year)%4==0 and int(year)%100!=0 and int(year)%400==0:
                two=29
            else:
                two=28
            days={
            '1':31,
            '2':two,
            '3':31,
            '4':30,
            '5':31,
            '6':30,
            '7':31,
            '8':31,
            '9':30,
            '10':31,
            '11':30,
            '12':31,
            }
            value=''
            history={}
            if year=='all' and month=='all':#全部
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                    
                
            elif year=='all' and month!='all':#所有月份为month的数据
                data=data_day(data,days,month)
                value='day'
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                Day=days[month]
            elif year!='all' and month=='all':#所有年份为year的数据
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
            elif year!='all' and month!='all':#所有年份为year月份为month的数据
                data=data_day(data,days,month)
                value='day'
                Day=days[month]
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
            res={'name':sname,'month':month,'Day':Day,'way':way,'value':value,'years':years,'year':year}
            for i,j in history.items():
                if j==[]:
                    res[f'{i}_money']= 0
                    res[f'{i}_count']= 0   
                else:
                    res[f'{i}_money']=round(j[0]['sum'],2)
                    res[f'{i}_count']= j[0]['count']
            
            return render(request,'dataview_root.html',res)
        year=request.GET.get('year')
        if year !=None:
            month=request.GET.get('month')
            way=request.GET.get('way')
            
        else:
            year='all'
            month=nowmonth
            way='全部'
        data=filter_time('数据分析',data,year,month,day,way)  
        
        if year=='all':
                two=29
        elif int(year)%4==0 and int(year)%100!=0 and int(year)%400==0:
                two=29
        else:
                two=28
        days={
            '1':31,
            '2':two,
            '3':31,
            '4':30,
            '5':31,
            '6':30,
            '7':31,
            '8':31,
            '9':30,
            '10':31,
            '11':30,
            '12':31,
            }
        value=''
        history={}
        if year=='all' and month=='all':#全部
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                    
                
        elif year=='all' and month!='all':#所有月份为month的数据
                data=data_day(data,days,month)
                value='day'
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                Day=days[month]
        elif year!='all' and month=='all':#所有年份为year的数据
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
        elif year!='all' and month!='all':#所有年份为year月份为month的数据
                data=data_day(data,days,month)
                value='day'
                Day=days[month]
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
        res={'name':sname,'month':month,'Day':Day,'way':way,'value':value,'years':years,'year':year}
        for i,j in history.items():
                if j==[]:
                    res[f'{i}_money']= 0
                    res[f'{i}_count']= 0   
                else:
                    res[f'{i}_money']=round(j[0]['sum'],2)
                    res[f'{i}_count']= j[0]['count']
        
        return render(request,'dataview_root.html',res)
def main(request):
    show=request.GET.get('show')
    sname=request.GET.get('sname')
    username=request.GET.get('username')
    password=request.GET.get('password')
    if password!=Users.objects.get(username=username).psw:#安全验证
            return HttpResponse(f'账号验证失败！')
    points=Points.objects.get(sname=sname).points
    years=datetime.datetime.now()
    nowmonth=str(years.month)
    years=[i for i in range(2021,years.year+1)] 
    if show=='营收情况':
        data=History.objects.filter(sname=sname)
        #时间筛选
        if request.POST:
            year=request.POST.get('year')
            month=request.POST.get('month')
            day=request.POST.get('day')
            way=request.POST.get('way')
            data=filter_time(show,data,year,month,day,way)   
            
            if data.exists():
                
                anono=data.aggregate(sum=Sum('总金额'),count=Count('总金额'))
                sum=anono['sum']
                count=anono['count']
                length=len(data)
                
                ID=[i for i in range(1,length+1)]
                res=list(zip(ID,data))
                paginator = Paginator(res, 23)
            else:
                sum=0
                count=0
                paginator = Paginator(data, 23)
            try:
                page_number = request.GET.get('page', '1')
                page = paginator.page(page_number)
            except (PageNotAnInteger, EmptyPage, InvalidPage):
            # 如果出现上述异常，默认展示第1页
                page = paginator.page(1)
            return render(request,'yingshou.html',{'username':username,'name':sname,'data':data,'years':years,'password':password,'page': page,'year':year,'month':month,'way':way,'sum':sum,'count':count,'day':day})
        year=request.GET.get('year')
        if year !=None:
            month=request.GET.get('month')
            day=request.GET.get('day')
            way=request.GET.get('way')
            
        else:
            year='all'
            month=nowmonth
            day='all'
            way='全部'
        data=filter_time(show,data,year,month,day,way)        
        if data.exists():
                anono=data.aggregate(sum=Sum('总金额'),count=Count('总金额'))
                sum=anono['sum']
                count=anono['count']
                
                paginator = Paginator(data, 23)
        else:
                sum=0
                count=0
                paginator = Paginator(data, 23)
      
        #ID
        
        length=len(data)
        
        ID=[i for i in range(1,length+1)]
        res=list(zip(ID,data))
        paginator = Paginator(res, 23)
        try:
            page_number = request.GET.get('page', '1')
            page = paginator.page(page_number)
        except (PageNotAnInteger, EmptyPage, InvalidPage):
        # 如果出现上述异常，默认展示第1页
            page = process_paginator(1)
        return render(request,'yingshou.html',{'username':username,'name':sname,'data':data,'years':years,'password':password,'sum':sum,'count':count,'day':day,'page': page,'year':year,'month':month,'way':way})
    elif show=='数据分析':
        data=History.objects.filter(sname=sname)
        #时间筛选
        day='all'
        if request.POST:
            year=request.POST.get('year')
            month=request.POST.get('month')
            
            way=request.POST.get('way')
            data=filter_time(show,data,year,month,day,way)
            
            if year=='all':
                two=29
            elif int(year)%4==0 and int(year)%100!=0 and int(year)%400==0:
                two=29
            else:
                two=28
            days={
            '1':31,
            '2':two,
            '3':31,
            '4':30,
            '5':31,
            '6':30,
            '7':31,
            '8':31,
            '9':30,
            '10':31,
            '11':30,
            '12':31,
            }
            value=''
            history={}
            if year=='all' and month=='all':#全部
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                    
                
            elif year=='all' and month!='all':#所有月份为month的数据
                data=data_day(data,days,month)
                value='day'
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                Day=days[month]
            elif year!='all' and month=='all':#所有年份为year的数据
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
            elif year!='all' and month!='all':#所有年份为year月份为month的数据
                data=data_day(data,days,month)
                value='day'
                Day=days[month]
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
            res={'username':username,'name':sname,'password':password,'month':month,'Day':Day,'way':way,'value':value,'years':years,'year':year}
            for i,j in history.items():
                if j==[]:
                    res[f'{i}_money']= 0
                    res[f'{i}_count']= 0   
                else:
                    res[f'{i}_money']=round(j[0]['sum'],2)
                    res[f'{i}_count']= j[0]['count']
            
            return render(request,'dataview.html',res)
        year=request.GET.get('year')
        if year !=None:
            month=request.GET.get('month')
            way=request.GET.get('way')
            
        else:
            year='all'
            month=nowmonth
            way='全部'
        data=filter_time(show,data,year,month,day,way)  
        
        if year=='all':
                two=29
        elif int(year)%4==0 and int(year)%100!=0 and int(year)%400==0:
                two=29
        else:
                two=28
        days={
            '1':31,
            '2':two,
            '3':31,
            '4':30,
            '5':31,
            '6':30,
            '7':31,
            '8':31,
            '9':30,
            '10':31,
            '11':30,
            '12':31,
            }
        value=''
        history={}
        if year=='all' and month=='all':#全部
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                    
                
        elif year=='all' and month!='all':#所有月份为month的数据
                data=data_day(data,days,month)
                value='day'
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
                Day=days[month]
        elif year!='all' and month=='all':#所有年份为year的数据
                data=data_month(data)
                value='month'
                Day=31
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
        elif year!='all' and month!='all':#所有年份为year月份为month的数据
                data=data_day(data,days,month)
                value='day'
                Day=days[month]
                for i,j in data:
                    history[i]=list(j.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
        res={'username':username,'name':sname,'password':password,'month':month,'Day':Day,'way':way,'value':value,'years':years,'year':year}
        for i,j in history.items():
                if j==[]:
                    res[f'{i}_money']= 0
                    res[f'{i}_count']= 0   
                else:
                    res[f'{i}_money']=round(j[0]['sum'],2)
                    res[f'{i}_count']= j[0]['count']
        
        return render(request,'dataview.html',res)
    elif show=='积分记录':
        data=Phistory.objects.filter(sname=sname).exclude(time=None)

        #时间筛选
        if request.POST:
            year=request.POST.get('year')
            month=request.POST.get('month')
            day=request.POST.get('day')
            way=request.POST.get('way')
            data=filter_time(show,data,year,month,day,way)    
            if data.exists():
                
                length=len(data)
                ID=[i for i in range(1,length+1)]
                res=list(zip(ID,data))
                paginator = Paginator(res, 23)
            else:
                paginator = Paginator(data, 23)
                length=0
            try:
                page_number = request.GET.get('page', '1')
                page = paginator.page(page_number)
            except (PageNotAnInteger, EmptyPage, InvalidPage):
            # 如果出现上述异常，默认展示第1页
                page = paginator.page(1)
            return render(request,'point_history.html',{'username':username,'name':sname,'data':data,'years':years,'password':password,'page': page,'year':year,'month':month,'day':day,'way':way,'points':points,'len':length})
        year=request.GET.get('year')
        if year !=None:
            month=request.GET.get('month')
            day=request.GET.get('day')
            way=request.GET.get('way')
        else:
            year='all'
            month=nowmonth
            day='all'
            way='全部'
        
        data=filter_time(show,data,year,month,day,way)        
        
        #ID
        length=len(data)
        ID=[i for i in range(1,length+1)]
        res=list(zip(ID,data))
        paginator = Paginator(res, 23)
        try:
            page_number = request.GET.get('page', '1')
            page = paginator.page(page_number)
        except (PageNotAnInteger, EmptyPage, InvalidPage):
        # 如果出现上述异常，默认展示第1页
            page = process_paginator(1)
        
        return render(request,'point_history.html',{'username':username,'name':sname,'data':data,'years':years,'password':password,'way':'全部','page': page,'year':year,'month':month,'day':day,'way':way,'points':points,'len':length})
    elif show=='积分商城':
        data=Goods.objects.all()
        
        return render(request,'point_shop.html',{'username':username,'name':sname,'password':password,'data':data})
    elif show=='购买记录':
        data=Order_shop.objects.filter(sname=sname)
        #时间筛选
        if request.POST:
            year=request.POST.get('year')
            month=request.POST.get('month')
            day=request.POST.get('day')
            way=request.POST.get('way')
            data=filter_time(show,data,year,month,day,way)    
            if data.exists():
                length=len(data)
                ID=[i for i in range(1,length+1)]
                res=list(zip(ID,data))
                paginator = Paginator(data, 23)
            else:
                paginator = Paginator(data, 23)
                length=0
            try:
                
                paginator = Paginator(res, 23)
                page_number = request.GET.get('page', '1')
                page = paginator.page(page_number)
            except (PageNotAnInteger, EmptyPage, InvalidPage):
            # 如果出现上述异常，默认展示第1页
                page = paginator.page(1)
            return render(request,'order_shop.html',{'username':username,'name':sname,'data':data,'years':years,'password':password,'page': page,'year':year,'month':month,'way':way,'day':day,'len':length})
        year=request.GET.get('year')
        if year !=None:
            month=request.GET.get('month')
            day=request.GET.get('day')
            way=request.GET.get('way')
            
        else:
            year='all'
            month=nowmonth
            day='all'
            way='全部'
        data=filter_time(show,data,year,month,day,way)        
        if data.exists():
            paginator = Paginator(data, 23)
        #ID
        length=len(data)
        ID=[i for i in range(1,length+1)]
        res=list(zip(ID,data))
        paginator = Paginator(res, 23)
        try:
            page_number = request.GET.get('page', '1')
            page = paginator.page(page_number)
        except (PageNotAnInteger, EmptyPage, InvalidPage):
        # 如果出现上述异常，默认展示第1页
            page = process_paginator(1)
        return render(request,'order_shop.html',{'username':username,'name':sname,'data':data,'years':years,'password':password,'day':day,'page': page,'year':year,'month':month,'way':way,'len':length})
def init(request):
    return render(request,'init.html')
def process_paginator(request, article_list):
    paginator = Paginator(article_list, 1)
    try:
        page_number = int(request.GET.get('page', '1'))
        page = paginator.page(page_number)
    except (PageNotAnInteger, EmptyPage, InvalidPage):
        page = paginator.page(1)
    return page
def logon(request):
    if request.POST:
        sname=request.POST.get('sname')
        username=request.POST.get('username')
        password=request.POST.get('password')
        rname=request.POST.get('rname')
        pay=request.POST.get('pay')
        phone=request.POST.get('phone')
        address=request.POST.get('address')
        tid=request.POST.get('tid')
        class1=request.POST.get('class1')
        class2=request.POST.get('class2')
        img1=request.FILES.get('img1')
        img2=request.FILES.get('img2')
        status=''
        form={'店铺名':sname,'用户名':username,'密码':password,'法人姓名':rname,'支付宝账号':pay,'手机号':phone,'地址':address,'推荐人ID':tid,'经营类别(一级)':class1,'经营类别(二级)':class2}
        
        for i,j in form.items():
            if j=='':
                e=f'{i}不能为空'
                status='false'
                return render(request,'logon.html',locals())
        try:
            Store.objects.get(sname=sname)
            e='店铺已入驻'
            status='false'
            return render(request,'logon.html',locals())
                    
        except:
            pass
            
        try:
            Users.objects.get(username=username)
            e='用户名已存在'
            status='false'
            return render(request,'logon.html',locals())
        except:
            pass
        try:
            Tpeople.objects.get(id=tid)
        except:
            e='业务员ID不存在'
            status='false'
            return render(request,'logon.html',locals())
        if img1==None:
            e='营业执照未上传'
            status='false'
            return render(request,'logon.html',locals())
        if img2==None:
            e='食品经营许可证未上传'
            status='false'
            return render(request,'logon.html',locals())
        try: 
            try:
                i=Users.objects.last()
                index=i.id+1
            except:
                index=1
        
            db=Users()
            db.sname=sname
            db.username=username
            db.psw=password
            db.rname=rname
            db.pay=pay
            db.phone=phone
            db.address=address
            db.业务员ID=tid
            db.经营类目一级=class1
            db.经营类目二级=class2
            db.营业执照.save(f'{index}_jy.jpg',img1)
            db.status='未认证'
            db.食品经营许可证.save(f'{index}_xkz.jpg',img2)
            db.save()
            status='True'
            return render(request,'logon.html',locals())
        except Exception as e:
            e=e
            status='false'
            return render(request,'logon.html',locals())
    return render(request,'logon.html',locals())
def showgoods(request):
    id=request.GET.get('id')
    sname=request.GET.get('sname')
    username=request.GET.get('username')
    password=request.GET.get('password')
    open=request.GET.get('open')
    if open=='phone':
        
        points=Points.objects.get(sname=sname).points
        if password!=Users.objects.get(username=username).psw:#安全验证
                return HttpResponse(f'账号验证失败！')
        data=Goods.objects.get(id=id)
        return render(request,'showgoods_phone.html',locals())
    else:
        points=Points.objects.get(sname=sname).points
        if password!=Users.objects.get(username=username).psw:#安全验证
                return HttpResponse(f'账号验证失败！')
        data=Goods.objects.get(id=id)
        return render(request,'showgoods.html',locals())
def Order(request):
    open=request.GET.get('open')
    sname=request.GET.get('sname')
    username=request.GET.get('username')
    password=request.GET.get('password')
    points=Points.objects.get(sname=sname).points#当前积分
    gname=request.POST.get('gname')#商品名
    num=request.POST.get('num')#数量
    point=Goods.objects.get(gname=gname).point#价格
    address=request.POST.get('address')#地址
    phone=request.POST.get('phone')#手机号
    oname=request.POST.get('oname')#收货人姓名
    
    status=''
    data=Goods.objects.get(gname=gname)
    points=Points.objects.get(sname=sname).points#当前积分
    if password!=Users.objects.get(username=username).psw:#安全验证
        
        if open=='phone':
            e='安全验证失败'
            status='false'
            return render(request,'showgoods_phone.html',locals())
        else:
            e='安全验证失败'
            status='false'
            return render(request,'showgoods.html',locals())
    if oname=='':
        if open=='phone':
            e='收货人不能为空'
            status='false'
            return render(request,'showgoods_phone.html',locals())
        else:
            e='收货人不能为空'
            status='false'
            return render(request,'showgoods.html',locals())
    if phone=='':
        if open=='phone':
            e='手机号不能为空'
            status='false'
            return render(request,'showgoods_phone.html',locals())
        else:
            e='手机号不能为空'
            status='false'
            return render(request,'showgoods.html',locals())
    if address=='':
        if open=='phone':
            e='地址不能为空'
            status='false'
            return render(request,'showgoods_phone.html',locals())
        else:
            e='地址不能为空'
            status='false'
            return render(request,'showgoods.html',locals())
        
    
    
    
    if points<int(point)*int(num):
        
        
        if open=='phone':
            e='积分不足'
            status='false'
            return render(request,'showgoods_phone.html',locals())
        else:
            e='积分不足'
            status='false'
            return render(request,'showgoods.html',locals())
    else:
        try:
            Order=Order_shop()
            Order.gname=gname
            Order.sname=sname
            Order.points=int(point)*int(num)
            Order.num=num
            Order.address=address
            Order.phone=phone
            Order.oname=oname
            Order.status='待发货'
            Order.kid='等待发货'
            Order.save()
            status='True'
            if open=='phone':
                data=Goods.objects.get(gname=gname)
                points=Points.objects.get(sname=sname).points#当前积分
                return render(request,'showgoods_phone.html',locals())
            else:
                data=Goods.objects.get(gname=gname)
                points=Points.objects.get(sname=sname).points#当前积分
                return render(request,'showgoods.html',locals())
        except Exception as e:
            
            e=e
            status='false'
            if open=='phone':
                
                return render(request,'showgoods_phone.html',locals())
            else:
                
                return render(request,'showgoods.html',locals())
    
# def datasee(request):
#     root=request.GET.get('root')
#     if root!='askdhkashdka1313':
#         return HttpResponse('404')
#     date=datetime.datetime.now()
#     year=date.year
#     month=date.month
#     day=date.day
    
#     data=History.objects.filter(付款时间__year=int(year)).filter(付款时间__month=int(month)).filter(付款时间__day=int(day))
    
#     anono=list(data.values('sname').annotate(sum=Sum('总金额'),count=Count('总金额')))
#     store=Store.objects.all().values_list()
#     stores_all=[]#商家列表
#     stores_now=[]#商家列表
#     for i in stores_all:
#         if i not in stores_now:
#             u=Users.objects.get(sname=i)#dajlfjlasjflasjf46546
#             anono.append({'sname':i,'sum': 0, 'count': 0})#,'username':u.username ,'password':u.psw
#     # for i in anono:
#     #     u=Users.objects.get(sname=i['sname'])
#     #     i['username']=u.username      
#     #     i['password']=u.psw
    
#     paginator = Paginator(data, 23)
#     length=len(anono)
#     ID=[i for i in range(1,length+1)]
#     res=list(zip(ID,anono))
#     paginator = Paginator(res, 23)
#     try:
#             page_number = request.GET.get('page', '1')
#             page = paginator.page(page_number)
#     except (PageNotAnInteger, EmptyPage, InvalidPage):
#         # 如果出现上述异常，默认展示第1页
#             page = process_paginator(1)
#     print(anono)
#     return render(request,'datasee.html',locals())