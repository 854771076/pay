from django.db import models
from django.utils.html import format_html
# Create your models here.

class Store(models.Model):
    id=models.AutoField(primary_key=True)
    Pid = models.CharField('餐馆ID',max_length=100)
    sname = models.CharField('餐馆名',max_length=255)
    status= models.CharField('状态',max_length=100)
    
    
    class Meta:
        managed = False
        db_table = 'store'
        verbose_name = '餐馆表'
        verbose_name_plural = '餐馆管理'
class History(models.Model):
    id=models.AutoField(primary_key=True)
    Pid=models.CharField('餐馆ID',max_length=100)
    
    sname= models.CharField('餐馆名',max_length=100)
    
    总金额= models.FloatField()
    付款方式=models.CharField(max_length=100)
    付款时间=models.DateTimeField()
    def __str__(self):
        return "%s:%s:%d:%s:%s"%(self.Pid,self.sname,self.总金额,self.付款方式,self.付款时间)
    class Meta:
        managed = False
        db_table = 'wmz_table'
        verbose_name = '餐馆收款记录表'
        verbose_name_plural = '餐馆收款记录管理'
class Users(models.Model):
    id=models.AutoField(primary_key=True)
    Pid = models.CharField('餐馆ID',max_length=100)
    sname= models.CharField('餐馆名',max_length=100)
    username=models.CharField('用户名',max_length=255)
    psw=models.CharField('密码',max_length=100)
    rname=models.CharField('法人姓名',max_length=100)
    pay=models.CharField('支付宝账号',max_length=100)
    phone=models.CharField('手机号',max_length=100)
    address=models.CharField('收货地址',max_length=255)
    经营类目一级=models.CharField('经营类目(一级)',max_length=255)
    经营类目二级=models.CharField('经营类目(二级)',max_length=255)
    业务员ID=models.CharField('业务员ID',max_length=100)
    营业执照=models.ImageField('营业执照',upload_to='static\\Users', height_field=None, width_field=None, max_length=None)
    食品经营许可证=models.ImageField('食品经营许可证',upload_to='static\\Users', height_field=None, width_field=None, max_length=None)
    status= models.CharField('状态',max_length=100)
    def image_data1(self):
        
        url='/'+str(self.营业执照).replace('b\'', '').replace('\'', '')
        
        if self.营业执照=="" or self.营业执照==None:
            url='/static/img/headpic.jpg'
        
        return format_html(
            '<img src="{}" width="100px"/>',
            url
        )
    image_data1.short_description = u'营业执照'
    def image_data2(self):
        url='/'+str(self.食品经营许可证).replace('b\'', '').replace('\'', '')
        if self.食品经营许可证=="" or self.食品经营许可证==None:
            url='/static/img/headpic.jpg'
        
        return format_html(
            '<img src="{}" width="100px"/>',
            url
        )
    image_data2.short_description = u'食品经营许可证'
    class Meta:
        managed = False
        db_table = 'users'
        verbose_name = '用户列表'
        verbose_name_plural = '用户列表管理'
class Phistory(models.Model):
    id=models.AutoField(primary_key=True)
    sname= models.CharField('餐馆名',max_length=100)
    point=models.IntegerField('积分')
    action=models.CharField('行为',max_length=255)
    time=models.DateTimeField('时间')
    class Meta:
        managed = False
        db_table = 'point_history'
        verbose_name = '积分记录表'
        verbose_name_plural = '积分记录管理'
class Points(models.Model):
    sname= models.CharField('餐馆名',max_length=100,primary_key=True)
    points=models.IntegerField('积分')
    class Meta:
        managed = False
        db_table = 'points'
class Goods(models.Model):
    id=models.AutoField(primary_key=True)
    gname= models.CharField('商品名',max_length=100)
    point=models.IntegerField('积分')
    content=models.CharField('简介',max_length=255)
    img=models.ImageField('图片',upload_to='static\\shop', height_field=None, width_field=None, max_length=None)
    
    def image_data(self):
        url='/'+str(self.img).replace('b\'', '').replace('\'', '')
        return format_html(
            '<img src="{}" width="100px"/>',
            url
        )
    image_data.short_description = u'图片'
    class Meta:
        managed = False
        db_table = 'goods'
        verbose_name = '商城商品表'
        verbose_name_plural = '商城商品管理'
class Order_shop(models.Model):
    id=models.AutoField(primary_key=True)
    sname= models.CharField('餐馆名',max_length=100)
    oname= models.CharField('收货人',max_length=100)
    gname= models.CharField('商品名',max_length=100)
    address= models.CharField('地址',max_length=255)
    num=models.IntegerField('数量')
    points=models.IntegerField('交易积分')
    time=models.DateTimeField('时间',auto_now=False, auto_now_add=True)
    phone=models.CharField('手机号',max_length=50)
    status=models.CharField('状态',max_length=50)
    kid=models.CharField('快递单号',max_length=255)
    class Meta:
        managed = False
        db_table = 'order_shop'
        verbose_name = '商城订单表'
        verbose_name_plural = '商城订单管理'
class Tpeople(models.Model):
    id=models.CharField('业务员ID',max_length=100,primary_key=True)
    tname=models.CharField('业务员',max_length=100)
    class Meta:
        managed = False
        db_table = 'tpeople'
        verbose_name = '业务员列表'
        verbose_name_plural = '业务员管理'