from django.contrib import admin
from .models import *
admin.site.site_header = '后台管理'  # 设置header
admin.site.site_title = '后台管理'   # 设置title
admin.site.index_title = '后台管理'

# Register your models here.
@admin.register(Users)
class UserAdmin(admin.ModelAdmin):
    list_display=['Pid','sname','username','psw','rname','pay','phone','address','经营类目一级','经营类目二级','业务员ID','image_data1','image_data2','status']
    search_fields=['Pid','worker','username','rname']
    list_display_links = ('sname',)
@admin.register(Phistory)
class UserAdmin(admin.ModelAdmin):
    list_display=['sname','point','action','time']
    search_fields=['sname','action','time']
@admin.register(History)
class UserAdmin(admin.ModelAdmin):
    list_display=['Pid','sname','总金额','付款方式','付款时间']
    search_fields=['Pid','sname','付款方式']
# @admin.register(Store)
# class UserAdmin(admin.ModelAdmin):
#     list_display=['Pid','sname','status']
#     search_fields=['Pid','sname','status']
#     list_display_links = ('sname', )
@admin.register(Goods)
class UserAdmin(admin.ModelAdmin):
    
    list_display=['gname','point','content','image_data']
    
    list_display_links = ('gname',)
    search_fields=['gname']
    
@admin.register(Order_shop)
class UserAdmin(admin.ModelAdmin):
    list_display=['sname','oname','gname','address','num','points','time','phone','status','kid']
    list_display_links = ('sname', )
    search_fields=['gname','phone','status','kid']
@admin.register(Tpeople)
class UserAdmin(admin.ModelAdmin):
    list_display=['id','tname']
    
    search_fields=['id','tname']