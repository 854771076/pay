from django.apps import AppConfig


class DataviewConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dataview'
    
    verbose_name = '数据库管理'
