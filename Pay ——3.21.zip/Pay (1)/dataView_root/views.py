from django.shortcuts import render
from .models import Store
from .models import History
from django.http import JsonResponse
from django.http import HttpResponse
from django.db.models import Sum,Count
import datetime
from django.core.paginator import Paginator, PageNotAnInteger, InvalidPage, EmptyPage
# Create your views here.

def index(request):
        
        
        return render(request, 'index_root.html',{'Time':'all allall'})
   
def showhistory(request,Time,sort,root):
    if root!='1564dfg6s4dfddfs':
         return HttpResponse('404')
    try:
        
        Time=Time.split(',')
        year=Time[0]
        month=Time[1]
        day=Time[2]
        name=Time[4]
        sname=[]
        
        if name=='all':
         h=History.objects
        else:
         h=History.objects.filter(sname__contains=name)      
        if year=='all ' and month=='all'  and day=='all':#全部
            
            history_zhi=h.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
            history_we=h.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
            if sort=='w_money':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-sum'))
            elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
            elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
            elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif  year=='all ' and month=='all'  and day!='all':#所有日期为day的数据
             t=h.filter(付款时间__day=int(day))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
            
             if sort=='w_money':
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif year=='all ' and month!='all'  and day=='all':#所有月份为month的数据
             t=h.filter(付款时间__month=int(month))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             
             if sort=='w_money':
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif year=='all ' and month!='all'  and day!='all':#所有日期为month-day的数据
             t=h.filter(付款时间__month=int(month)).filter(付款时间__day=int(day))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             
             if sort=='w_money':
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif year!='all ' and month=='all'  and day=='all':#所有年份为year的数据
             t=h.filter(付款时间__year=int(year))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             
             if sort=='w_money':
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif  year!='all ' and month=='all'  and day!='all':#所有年份为year鈤为day的数据
             t=h.filter(付款时间__year=int(year)).filter(付款时间__day=int(day))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             
             if sort=='w_money':
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif year!='all ' and month!='all'  and day=='all':#所有年份为year月份为month的数据
             t=h.filter(付款时间__year=int(year)).filter(付款时间__month=int(month))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             
             if sort=='w_money':
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        elif year!='all ' and month!='all'  and day!='all':#所有日期为year-month-day的数据
             t=h.filter(付款时间__year=int(year)).filter(付款时间__month=int(month)).filter(付款时间__day=int(day))
             history_zhi=t.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             history_we=t.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额'))
             
             if sort=='w_money':
                    
                    history_zhi=list(history_zhi)
                    history_we=list(history_we.order_by('-sum'))
             elif sort=='w_sum':
                history_zhi=list(history_zhi)
                history_we=list(history_we.order_by('-count'))
             elif sort=='z_money':
                history_zhi=list(history_zhi.order_by('-sum'))
                history_we=list(history_we)
             elif sort=='z_sum':
                    
                history_zhi=list(history_zhi.order_by('-count'))
                history_we=list(history_we)
        all_zhi_money=0
        all_we_money=0
        all_zhi_count=0
        all_we_count=0
        for i in history_zhi:
               all_zhi_money+=i['sum']
               all_zhi_count+=i['count']
        for i in history_we:
               all_we_money+=i['sum']
               all_we_count+=i['count']
        
        s=list((Store.objects.all().values_list()))
        for i in s:
            sname.append(i[1])
        res=[]
        Id=1
        zhi=[ i['sname'] for i in history_zhi]
        we=[ i['sname'] for i in history_we]     
       
        for i in sname:
                if  i not in zhi:
                    history_zhi.append({'sname':i, 'sum': 0, 'count': 0})
                if i not in we:
                        history_we.append({'sname':i, 'sum': 0, 'count': 0})
        if sort=='w_money' or sort=='w_sum':    
            for i in history_we:    
                for j in history_zhi:
                    if i['sname']==j['sname']:
                        res.append((Id,i,j))
                        Id+=1
        elif sort=='z_money' or sort=='z_sum':  
            for i in history_zhi:    
                for j in history_we:
                    if i['sname']==j['sname']:
                        res.append((Id,j,i))
                        Id+=1
        paginator = Paginator(res, 23)
        try:
            page_number = request.GET.get('page', '1')
            page = paginator.page(page_number)
        except (PageNotAnInteger, EmptyPage, InvalidPage):
        # 如果出现上述异常，默认展示第1页
            page = paginator.page(1)

        context={'data':res,'all_zhi_money':all_zhi_money,'all_we_money':all_we_money,'all_zhi_count':all_zhi_count,'all_we_count':all_we_count,'page': page}
        return render(request, 'showhistory_root.html',context)
    except Exception as e:
        return HttpResponse(f'Erorr:{e}')
# date='all ,all,all,pai,all'
value='w_sum'
def process_paginator(request, article_list):
    paginator = Paginator(article_list, 1)
    try:
        page_number = int(request.GET.get('page', '1'))
        page = paginator.page(page_number)
    except (PageNotAnInteger, EmptyPage, InvalidPage):
        page = paginator.page(1)
    return page

def filter_time(request):
        root=request.GET.get('root')
        if root!='askdhkashdka1313':
         return HttpResponse('404')
        years=datetime.datetime.now()
        y=years.year
        m=years.month
        d=years.day
        years=[i for i in range(2021,years.year+1)]   
       
        sname=list((Store.objects.all().values_list()))
        names=[]
        for i,j in sname:
               names.append(j)
        year=request.POST.get('year')
        
        
        global value
        if year!=None:
            month=request.POST.get('month')
            day=request.POST.get('day')
            n=request.POST.get('names').split(',')
            tab=n[0]
            name=n[1]
            
            if request.POST.get('name') != '':
               name=request.POST.get('name')
            Time=f'{year},{month},{day},{tab},{name}'
            
            date=Time
            print(date,Time)
            context={'Time':Time,'value':value,'names':names,'names':names,'years':years}
            return render(request, 'index_root.html',context)
        else:
            date=f'{y},{m},{d}, ,all'
            
            
            if request.POST.get('w_sum')!=None:
               value=request.POST.get('w_sum')
            if request.POST.get('w_money')!=None:
                value=request.POST.get('w_money')
            if request.POST.get('z_sum')!=None:
                value=request.POST.get('z_sum')
            if request.POST.get('z_money')!=None:
                value=request.POST.get('z_money')
            
            context={'Time':date,'value':value,'names':names,'years':years}
            return render(request, 'index_root.html',context)
def data_day(history,days,month):
      dic={}
      for i in range(1,days[month]+1):   
         dic[f'{i}']=history.filter(付款时间__day=i)
      return dic.items()
def data_month(history):
      dic={}
      for i in range(1,13):   
         dic[f'{i}']=history.filter(付款时间__month=i)
      return dic.items()
# def dataView(request,Time,sort):
#    try:
#         Time=Time.split(',')
#         year=Time[0]
#         month=Time[1]
#         name=Time[4]
#         history_zhi={}
#         history_we={}
#         if year=='all ':
#             two=29
#         elif int(year)%4==0 and int(year)%100!=0 and int(year)%400==0:
#             two=29
#         else:
#              two=28
#         days={
#            '1':31,
#            '2':two,
#            '3':31,
#            '4':30,
#            '5':31,
#            '6':30,
#            '7':31,
#            '8':31,
#            '9':30,
#            '10':31,
#            '11':30,
#            '12':31,
#         }
        
#         value=''
#         h=History.objects.filter(sname=name)      
#         if year=='all ' and month=='all':#全部
#             h=data_month(h)
#             value='month'
#             day=31
#             for i,j in h:
#                history_zhi[i]=list(j.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
#                history_we[i]=list(j.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
                
#         elif year=='all ' and month!='all':#所有月份为month的数据
#              h=h.filter(付款时间__month=int(month))
#              h=data_day(h,days,month)
#              value='day'
#              for i,j in h:
#                history_zhi[i]=list(j.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
#                history_we[i]=list(j.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
#              day=days[month]
#         elif year!='all ' and month=='all':#所有年份为year的数据
#              h=h.filter(付款时间__year=int(year))
#              h=data_month(h)
#              value='month'
#              day=31
#              for i,j in h:
#                history_zhi[i]=list(j.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
#                history_we[i]=list(j.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
             
             
#         elif year!='all ' and month!='all':#所有年份为year月份为month的数据
#              h=h.filter(付款时间__year=int(year)).filter(付款时间__month=int(month))
#              h=data_day(h,days,month)
#              value='day'
#              day=days[month]
#              for i,j in h:
#                history_zhi[i]=list(j.values('sname').filter(付款方式='支付宝支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
#                history_we[i]=list(j.values('sname').filter(付款方式='微信支付').annotate(sum=Sum('总金额'),count=Count('总金额')))
    
#         context={'v':value,'day':day}
#         for i,j in history_zhi.items():
#             if j==[]:
#                context[f'zhi_{i}_money']= 0
#                context[f'zhi_{i}_count']= 0   
#             else:
#                context[f'zhi_{i}_money']=round(j[0]['sum'],2)
#                context[f'zhi_{i}_count']= j[0]['count']
#         for i,j in history_we.items():
#             if j==[]:
#                context[f'we_{i}_money']= 0
#                context[f'we_{i}_count']= 0    
#             else:
#                context[f'we_{i}_money']=round(j[0]['sum'],2)
#                context[f'we_{i}_count']= j[0]['count']
        
#         return render(request, 'dataView.html',context)
#    except Exception as e:
#         return HttpResponse(f'Erorr:{e}')