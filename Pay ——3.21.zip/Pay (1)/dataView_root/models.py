from django.db import models

# Create your models here.
class Store(models.Model):
    Pid = models.CharField(primary_key=True,max_length=100)
    
    sname = models.CharField(max_length=255)
    def __str__(self):
        return "%d:%s"%(self.Pid,self.sname)
    
    class Meta:
        managed = True
        db_table = 'store'
        verbose_name = '餐馆列表'
        verbose_name_plural = '餐馆列表管理'
class History(models.Model):
    Pid=models.CharField(primary_key=True,max_length=100)
    
    sname= models.CharField(max_length=100)
    
    总金额= models.FloatField()
    付款方式=models.CharField(max_length=100)
    付款时间=models.DateTimeField()
    def __str__(self):
        return "%s:%s:%d:%s:%s"%(self.Pid,self.sname,self.总金额,self.付款方式,self.付款时间)
    class Meta:
        managed = True
        db_table = 'wmz_table'
        verbose_name = '餐馆订单记录'
        verbose_name_plural = '餐馆订单记录管理'