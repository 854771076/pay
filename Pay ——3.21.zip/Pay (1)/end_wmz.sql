/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : wmz

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2022-03-18 01:20:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES ('1', 'Can add log entry', '1', 'add_logentry');
INSERT INTO `auth_permission` VALUES ('2', 'Can change log entry', '1', 'change_logentry');
INSERT INTO `auth_permission` VALUES ('3', 'Can delete log entry', '1', 'delete_logentry');
INSERT INTO `auth_permission` VALUES ('4', 'Can view log entry', '1', 'view_logentry');
INSERT INTO `auth_permission` VALUES ('5', 'Can add permission', '2', 'add_permission');
INSERT INTO `auth_permission` VALUES ('6', 'Can change permission', '2', 'change_permission');
INSERT INTO `auth_permission` VALUES ('7', 'Can delete permission', '2', 'delete_permission');
INSERT INTO `auth_permission` VALUES ('8', 'Can view permission', '2', 'view_permission');
INSERT INTO `auth_permission` VALUES ('9', 'Can add group', '3', 'add_group');
INSERT INTO `auth_permission` VALUES ('10', 'Can change group', '3', 'change_group');
INSERT INTO `auth_permission` VALUES ('11', 'Can delete group', '3', 'delete_group');
INSERT INTO `auth_permission` VALUES ('12', 'Can view group', '3', 'view_group');
INSERT INTO `auth_permission` VALUES ('13', 'Can add user', '4', 'add_user');
INSERT INTO `auth_permission` VALUES ('14', 'Can change user', '4', 'change_user');
INSERT INTO `auth_permission` VALUES ('15', 'Can delete user', '4', 'delete_user');
INSERT INTO `auth_permission` VALUES ('16', 'Can view user', '4', 'view_user');
INSERT INTO `auth_permission` VALUES ('17', 'Can add content type', '5', 'add_contenttype');
INSERT INTO `auth_permission` VALUES ('18', 'Can change content type', '5', 'change_contenttype');
INSERT INTO `auth_permission` VALUES ('19', 'Can delete content type', '5', 'delete_contenttype');
INSERT INTO `auth_permission` VALUES ('20', 'Can view content type', '5', 'view_contenttype');
INSERT INTO `auth_permission` VALUES ('21', 'Can add session', '6', 'add_session');
INSERT INTO `auth_permission` VALUES ('22', 'Can change session', '6', 'change_session');
INSERT INTO `auth_permission` VALUES ('23', 'Can delete session', '6', 'delete_session');
INSERT INTO `auth_permission` VALUES ('24', 'Can view session', '6', 'view_session');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_user
-- ----------------------------
INSERT INTO `auth_user` VALUES ('1', 'pbkdf2_sha256$320000$IPKfQeKI8WnEOrAlwAsRla$pEfEnsdCr4ywZK0/T46DcFNacu7uedjO7vQmOS7BW34=', '2022-03-17 08:57:09.696447', '1', 'root', '', '', 'root@qq.com', '1', '1', '2022-03-12 18:36:01.946853');

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------
INSERT INTO `django_admin_log` VALUES ('1', '2022-03-12 18:38:44.881063', '2', 'Phistory object (2)', '3', '', '7', '1');
INSERT INTO `django_admin_log` VALUES ('2', '2022-03-17 16:16:12.332767', '209030234', 'Tpeople object (209030234)', '1', '[{\"added\": {}}]', '13', '1');
INSERT INTO `django_admin_log` VALUES ('3', '2022-03-17 16:23:19.991164', '1', 'Store object (1)', '2', '[{\"changed\": {\"fields\": [\"\\u9910\\u9986ID\"]}}]', '11', '1');
INSERT INTO `django_admin_log` VALUES ('4', '2022-03-17 16:23:28.655314', '1', '209030234:小洋面庄:10:微信支付:2022-03-17 16:21:00', '1', '[{\"added\": {}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('5', '2022-03-17 17:49:42.388196', '3', 'Goods object (3)', '1', '[{\"added\": {}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('6', '2022-03-17 17:52:55.387244', '3', 'Goods object (3)', '2', '[{\"changed\": {\"fields\": [\"\\u56fe\\u7247\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('7', '2022-03-17 22:54:20.787239', '3', 'Goods object (3)', '3', '', '8', '1');
INSERT INTO `django_admin_log` VALUES ('8', '2022-03-18 00:05:25.173907', '1', 'Users object (1)', '3', '', '9', '1');
INSERT INTO `django_admin_log` VALUES ('9', '2022-03-18 01:01:48.383933', '4', 'Users object (4)', '1', '[{\"added\": {}}]', '9', '1');

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES ('1', 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES ('2', 'auth', 'permission');
INSERT INTO `django_content_type` VALUES ('3', 'auth', 'group');
INSERT INTO `django_content_type` VALUES ('4', 'auth', 'user');
INSERT INTO `django_content_type` VALUES ('5', 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES ('6', 'sessions', 'session');
INSERT INTO `django_content_type` VALUES ('7', 'dataview', 'phistory');
INSERT INTO `django_content_type` VALUES ('8', 'dataview', 'goods');
INSERT INTO `django_content_type` VALUES ('9', 'dataview', 'users');
INSERT INTO `django_content_type` VALUES ('10', 'dataview', 'history');
INSERT INTO `django_content_type` VALUES ('11', 'dataview', 'store');
INSERT INTO `django_content_type` VALUES ('12', 'dataview', 'order_shop');
INSERT INTO `django_content_type` VALUES ('13', 'dataview', 'tpeople');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES ('1', 'contenttypes', '0001_initial', '2022-03-12 18:34:03.556663');
INSERT INTO `django_migrations` VALUES ('2', 'auth', '0001_initial', '2022-03-12 18:34:03.675252');
INSERT INTO `django_migrations` VALUES ('3', 'admin', '0001_initial', '2022-03-12 18:34:03.706879');
INSERT INTO `django_migrations` VALUES ('4', 'admin', '0002_logentry_remove_auto_add', '2022-03-12 18:34:03.712864');
INSERT INTO `django_migrations` VALUES ('5', 'admin', '0003_logentry_add_action_flag_choices', '2022-03-12 18:34:03.718847');
INSERT INTO `django_migrations` VALUES ('6', 'contenttypes', '0002_remove_content_type_name', '2022-03-12 18:34:03.741378');
INSERT INTO `django_migrations` VALUES ('7', 'auth', '0002_alter_permission_name_max_length', '2022-03-12 18:34:03.753346');
INSERT INTO `django_migrations` VALUES ('8', 'auth', '0003_alter_user_email_max_length', '2022-03-12 18:34:03.764334');
INSERT INTO `django_migrations` VALUES ('9', 'auth', '0004_alter_user_username_opts', '2022-03-12 18:34:03.769320');
INSERT INTO `django_migrations` VALUES ('10', 'auth', '0005_alter_user_last_login_null', '2022-03-12 18:34:03.782287');
INSERT INTO `django_migrations` VALUES ('11', 'auth', '0006_require_contenttypes_0002', '2022-03-12 18:34:03.783283');
INSERT INTO `django_migrations` VALUES ('12', 'auth', '0007_alter_validators_add_error_messages', '2022-03-12 18:34:03.789267');
INSERT INTO `django_migrations` VALUES ('13', 'auth', '0008_alter_user_username_max_length', '2022-03-12 18:34:03.801235');
INSERT INTO `django_migrations` VALUES ('14', 'auth', '0009_alter_user_last_name_max_length', '2022-03-12 18:34:03.814092');
INSERT INTO `django_migrations` VALUES ('15', 'auth', '0010_alter_group_name_max_length', '2022-03-12 18:34:03.825062');
INSERT INTO `django_migrations` VALUES ('16', 'auth', '0011_update_proxy_permissions', '2022-03-12 18:34:03.831046');
INSERT INTO `django_migrations` VALUES ('17', 'auth', '0012_alter_user_first_name_max_length', '2022-03-12 18:34:03.843014');
INSERT INTO `django_migrations` VALUES ('18', 'sessions', '0001_initial', '2022-03-12 18:34:03.854810');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('oep2nfw9nbvdl33800bfk1ridr56mou1', '.eJxVjskOwiAURf-FtSFAGYpL935D8x6DrQMYaGOM8d-lpgtd3unkvsgAyzwOSw1lmDzZE052vx6Cu4S0Bv4M6ZSpy2kuE9K1Qre00mP24XrYun-AEerY1n0vubMKtbLRMsOajJZrLXgQgAJ5lAINdML0jhmMDK3isvOagReGhQZdcQluodGetek71PrI5XtadFJp8v4AO-JBqw:1nUKL6:zfLN5gFH7tSNXFdDZWh3UlwUAi2gzYEE2SCXHtIcRXo', '2022-03-30 03:28:44.740475');
INSERT INTO `django_session` VALUES ('9n89n4md026tx5t4dt58d775nzo0p3dc', 'eyJ1c2VybmFtZSI6InlzIiwicGFzc3dvcmQiOiIxMjM0NTYifQ:1nU1Qz:_DYrPYWrlUxQV9liurmxX_dhB8xEsTMeCemfnZHdr84', '2022-03-29 07:17:33.758820');
INSERT INTO `django_session` VALUES ('osooh951ttshk03a3xinpxuzdu0sc932', 'eyJ1c2VybmFtZSI6InlzIiwicGFzc3dvcmQiOiIxMjM0NTYifQ:1nTmq3:yr4Kl6XwDfKCUyuQDSxYrf7WnSY2YeMUmv5wpclpXGo', '2022-03-28 15:42:27.102263');
INSERT INTO `django_session` VALUES ('kz1ndhhhlcqifqdrmyoxh76u9cm64hv5', 'eyJ1c2VybmFtZSI6InlzIiwicGFzc3dvcmQiOiIxMjM0NTYifQ:1nU0LA:2vfGd1ybRDtMGxGezbTjNA9MDP3DvGQpjPReKub55_w', '2022-03-29 06:07:28.426033');
INSERT INTO `django_session` VALUES ('j49uguoymmat1ky7ywwysrbm55dk5sf8', 'eyJ1c2VybmFtZSI6InlzIiwicGFzc3dvcmQiOiIxMjM0NTYifQ:1nUOyN:F6eNqMIq1bn9j72_X4UF2I4UqjpCXrYjSmcIus-Tjw8', '2022-03-30 16:25:35.689477');
INSERT INTO `django_session` VALUES ('1b3kau705xbqqt0jayatdh92e0n3lmdv', 'eyJ1c2VybmFtZSI6InlzIiwicGFzc3dvcmQiOiIxMjM0NTYifQ:1nUREa:h8jUwavL40hf65o1XfnQzbuUesoK2z47Dqc9HMANPWM', '2022-03-30 18:50:28.600786');
INSERT INTO `django_session` VALUES ('88urra1a76e5sb564v18db0lmwmv80na', '.eJzNVstu2zAQ_JVAZz_4JpVj7z32VAUGX7LU2pIhWg2CwP9ekjJaR1FsNZVhnxbkjjjcGYrL16R1tqnk1iaPyYtLZslOOvdcN8aPIcKEMj-3ku2-WAXkqoyJt3NK6p-2CgnzQ1breqHrat-UahEgi2PWLb7Wxm6-HLFvFiikK_zXQhCoU6oYTfMUcOCHeQoZQ9AiqZCCOUGKS4y40ICrHKiUQoINA9IgDmxYdGur1vm1vr9mSSgrSx4fsiTLWkY5CAEz6wO1KfaBKwlDIIBlycwDS7_17pNcNg-5nOuy0RvbJbehABfS71anlLAQuLYnI6LhP5O0zabLLaXZltXSyL38Vdrn5bqujVt2IGnMt_M4jzhiVWOl0U27VcNb_09hDrOH64hxeAppW5qQhQCgi0xCSRRGmNLpZPe_gj-hrqh3I7Q_Ad-PAZ-VpW8AHmDiFImwd4R5oEAwBCGYmM6AcEOMOfcd7payTyNGX3YyxJTaPFIAFg1WoRKaT3nud0Xp9nXzMkL5P9Cbij-JJH3x6QBTmkIQg2CxEhyDwvZaVox34h6MuIY8fVvYRd6JpA9y2hHCd7j7kf3z0vL-BBwg8y2FxBB7OiVCx2JEvP44we85XeB0RWk3Zi43-4sPqtO7dLiAcN8PuxcelrEdfGzcX8h4zyYo-kLTOFdo35Z0aC2ryQe7iN1xruv1GcnWTd2eeeWcYG4u2qhCe5JB0NdQHJ6Sw295fAne:1nUfd8:5hTG4JkVnyEXafXqNxUQw-dNblEa7Mfabc1XfJAsGqQ', '2022-03-31 10:12:46.855247');
INSERT INTO `django_session` VALUES ('prkcvbz61pu5i8vu5352kr9f6nj0sggr', '.eJzNlkuPmzAQx79KxDkPvw177L3Hnsoq8otAyyPC0FW1ynevbaI2y7IJbVllTyN7_sx4foMHnqPemrYWlYkeos7YLlpHR2HtU9NqtwMRJpS5vb3ou3zvtfsiOF7uSaG-m9o79DdRH5qtauquLeTWS7Znr91-brQpP521LwLkwubu6TgmUCVUMppkCeDALbMEMoagQUIiCTOCJBcY8VgBLjMgEwoJ1gwIjTgwPmhl6t66WF-f08gXlkYPqzRK055RDrzBzDhDTYKd4VJAbwhgabR2wsIdfXgkE-0qExtVtKo0g7PyBVjvfhWdGCh8WBTiUULjv47et-Xg2wldFfVOi078KMzTrjua5lia3SATWn-5pXSas1q2RmjV9pWcPvd_UjmtVwuTOD16tym090IA0EQKSgnzhitzsSIKLsf80DTaziA-6O7JexkYY-z4ZqZYCuRXmNLlsLu548aBzZvjDPYX4o_TgH_FMm4AmcjEKfKXiSHMww2D3sQxW3DW-HE8570fdPfEvgyMMXY6lSkxWUgBWGiw9JXQbMn3_pgXtmvanzPI_5beFf4iSMbw2USmJIEgmJiFSnAwEpv3asX8TnyERrwHnnFb-HgDThzEzT0SjBo--7EKhcbhjnKCX-e0PqfNC1PqjSi7m79Ylxd-ugA_lKa76381w8x6u61_JPP7uUDRNybbtULHbUmmYhlF3jhFGOEb1RyuIDu0TX_lU3yhuTu0WYWOkEEwZhifHqPTL-V5ETI:1nUtiP:H-NbApO_1RxdMYDCMWs9wjrDe6Xio_aLo51PAzHOWVI', '2022-04-01 01:15:09.616850');
INSERT INTO `django_session` VALUES ('gb0d1ri07gs7gzo87z22enz6m5ejnufm', '.eJzNlsuOmzAUhl8lYp2LbXxjlrPvsqsyinwj0OEyMtCqGuXdi03UUoZJmClRsjoy58fH5_st26_BXrRNum9rY_eZDh4CGKyH36RQz6Z0Cf1dlIdqq6qysZncOsn2lK23Xypt8seT9p8JUlGn3d-cY6giIimJkggw0A2TCFKKoEFCIgkTjCQTIWJcASYTICMCcagpEBoxYNykhSnbupvr22sclKIwcfCwioM4bilhwIWQmi4QE4VdYFJAFzCgcbDuhFm39P6XRNhVIjYqsyo3fbJwDdQu_WZ2QjB1gSkzGGEFP1yktXmf2wldZOVOi0b8yMzP3aGqdL3rRULrr-d1neKkldYIrWxbyOml_yeY43p1HRjHJ5c2mXZZCAC6WIlLgdwoJGQ57JXV3Q6t0-plBvuB-H4M-CyWsQHhRCVGEHdrRyFzJRB0gXPKlzPAnRBz9n2vuyX2ZWCMseOpSpFJfAlAvcHSdUKSJff9S5rVTWV_zSD_R3pT-IsgGcMnE5WiCAIfOPWdhD7I0FzLivlO3IMR18AztoVerLsQeofTzADf6-4H--fRsvEHOFGsu1KwD_5OJ5gr3wz3xx_D4duatatZp5nJ9UbkzcUH1fAsnW7AnffT7rmHpb8O3jfur2S-Zws0feHSONfo2JZoai6j8Dur8LfjRlWHM8gOtmrPvHIGmptDm9XoCBkEY4b8-BQcfwNjAP7_:1nUWD0:tP75CIzy5jV0fPLYAQekaQ1LarI7yoB5rZAr7OT7MvU', '2022-03-31 00:09:10.173917');
INSERT INTO `django_session` VALUES ('yjjvhn79z6a1jqkjivdnz1pse4hgvm7f', '.eJzNlkuPmzAQx79KxDkP2_gBe-y9x57KKvKLQEtwhKFRtcp3r22iNmXZhG5ZJacRnj8znt_A2C9RZ3VT872OniJ-tJW2NlpGB27t0TTKLR4NTAmCbnHLu7bYev229J7BmuDyu669Q33j9c6spanbphRrL1mfvXb92ShdfTpr_wpQcFu4t5MEQ5kSQUmap4AB95inkFIENeICCZhjJBiPEUskYCIHIiUQx4oCrhAD2gfd67qzLtbXlyzyxWXR0yKLsqyjhAFvYqqdITqNnWGCQ28woFm0dMLSbb1_JefNIucrWTay0r1z7wuw3v0qOtaQ-7AoxCOYJP8cvWuq3rfhal_WG8Vb_qPUx0170OZQ6U0v40p9uaV0mrNaNJor2XR7Mb7v_6RyWi5mJnF69m5dKu-FAKCRFIRg6g2T-uIJSzgf850xyk4g3uvuyXseGEPs8c1MieDIP8WEzIfdDR43DmxhDhPYX4gfpwHvxTJsAB7JxAjyPxNFMQt_GPQmSeiMs8aP4ynffa-7J_Z5YAyxk7FMqc5DCkBDg4WvhORzfveHorStaX5OIP9belf4syAZwqcjmdIUgmASGiqJgxGx_qhWTO_EIzTiI_AM28Ju5p0Jvcc55ZrT6x4H-_vRJsMFOJLMHSk4GNnfqBIZiknC-GM4fp3T-py2KHWlVrxqb95eL2fpeAF-3o93z9_iw3HwduP-SKb3bIaibxwa1wodtAWCsVha4jd2EU7HlTS7K8h2jemu3HIuNHeHNqnQITI4_LTT03N0-gWb3n5d:1nUmwg:CXKT20Eq2NQg5FTqtL8nVKEDb-km387LYW9xqGq26bg', '2022-03-31 18:01:26.329982');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `point` int(11) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `img` mediumblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('1', '50', '金龙鱼黄金玉米油', '金龙鱼黄金玉米油', 0x7374617469632F73686F702F73686F70315F6B6759536A6E392E6A7067);
INSERT INTO `goods` VALUES ('2', '40', '泰国珍珠米', '泰国珍珠米', 0x7374617469632F73686F702F73686F70322E6A7067);

-- ----------------------------
-- Table structure for order_shop
-- ----------------------------
DROP TABLE IF EXISTS `order_shop`;
CREATE TABLE `order_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(255) NOT NULL,
  `oname` varchar(255) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `status` varchar(50) DEFAULT '待发货',
  `kid` varchar(255) DEFAULT '等待发货',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_shop
-- ----------------------------

-- ----------------------------
-- Table structure for point_history
-- ----------------------------
DROP TABLE IF EXISTS `point_history`;
CREATE TABLE `point_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` char(100) NOT NULL,
  `point` int(11) NOT NULL DEFAULT '1',
  `action` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `oid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of point_history
-- ----------------------------

-- ----------------------------
-- Table structure for tpeople
-- ----------------------------
DROP TABLE IF EXISTS `tpeople`;
CREATE TABLE `tpeople` (
  `id` varchar(100) NOT NULL,
  `tname` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tpeople
-- ----------------------------
INSERT INTO `tpeople` VALUES ('209030234', '付洋');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `PID` char(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` char(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `psw` varchar(255) NOT NULL,
  `rname` varchar(255) DEFAULT NULL,
  `pay` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `经营类目一级` varchar(255) DEFAULT NULL,
  `经营类目二级` varchar(255) DEFAULT NULL,
  `业务员ID` varchar(20) DEFAULT NULL,
  `营业执照` mediumblob,
  `食品经营许可证` mediumblob,
  `status` varchar(20) DEFAULT '未认证',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------

-- ----------------------------
-- Table structure for wmz_table
-- ----------------------------
DROP TABLE IF EXISTS `wmz_table`;
CREATE TABLE `wmz_table` (
  `PID` char(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `sname` char(100) DEFAULT NULL,
  `总金额` float DEFAULT NULL,
  `付款方式` char(100) DEFAULT NULL,
  `付款时间` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of wmz_table
-- ----------------------------

-- ----------------------------
-- View structure for points
-- ----------------------------
DROP VIEW IF EXISTS `points`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `points` AS select `point_history`.`sname` AS `sname`,sum(`point_history`.`point`) AS `points` from `point_history` group by `point_history`.`sname` ;

-- ----------------------------
-- View structure for store
-- ----------------------------
DROP VIEW IF EXISTS `store`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `store` AS select `users`.`id` AS `id`,`users`.`PID` AS `Pid`,`users`.`sname` AS `sname`,`users`.`status` AS `status` from `users` ;
DROP TRIGGER IF EXISTS `add_order`;
DELIMITER ;;
CREATE TRIGGER `add_order` AFTER INSERT ON `order_shop` FOR EACH ROW BEGIN
		insert into point_history(sname,point,action,time,oid) VALUES(new.sname,-abs(new.points),'购物',new.time,new.id); 
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `jian_order`;
DELIMITER ;;
CREATE TRIGGER `jian_order` AFTER DELETE ON `order_shop` FOR EACH ROW BEGIN
		DELETE from point_history where oid=old.id;
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `init_point`;
DELIMITER ;;
CREATE TRIGGER `init_point` AFTER INSERT ON `users` FOR EACH ROW BEGIN
		insert into point_history(sname,point) VALUES(new.sname,0); 
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `add_point_history`;
DELIMITER ;;
CREATE TRIGGER `add_point_history` AFTER INSERT ON `wmz_table` FOR EACH ROW BEGIN
	IF new.总金额>=7 THEN  #积分条件
		insert into point_history(sname,point,action,time) VALUES(new.sname,1,'收款',new.付款时间); 
	END IF;
END
;;
DELIMITER ;
